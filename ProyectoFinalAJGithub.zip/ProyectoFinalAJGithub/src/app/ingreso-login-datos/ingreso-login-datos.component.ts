import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Usuario } from '../data/usuario';
import { Router } from '@angular/router';
import { RestUsuarioService } from '../services/rest-usuario.service';
import { NgIf } from '@angular/common';


@Component({
  selector: 'app-ingreso-login-datos',
  standalone: true,
  imports: [FormsModule, NgIf],
  templateUrl: './ingreso-login-datos.component.html',
  styleUrl: './ingreso-login-datos.component.css'

})
export class IngresoLoginDatosComponent {
  usuario: Usuario = new Usuario();
  message: string = "";

  constructor(
    private restUsuariosService: RestUsuarioService,
    private router: Router
  ) {}

  logUsuario() {
    this.restUsuariosService.logUsuario(this.usuario).subscribe(
      (result) => {
        if (result.success) {
          // Guarda el id_usuario y nombre_usuario en localStorage después del inicio de sesión exitoso
          localStorage.setItem('id_usuario', result.data.id_usuario.toString());
          localStorage.setItem('nombre_usuario', result.data.usuario);
          this.message = 'Inicio de sesión exitoso';
  
          // Redirige a la ruta deseada después del inicio de sesión exitoso
          this.router.navigate(['/LoginE']);
  
          // Borra el mensaje después de 3 segundos
          setTimeout(() => {
            this.message = '';
          }, 3000);
        } else {
          this.message = result.message || 'Usuario o contraseña incorrectos';
  
          // Borra el mensaje después de 3 segundos
          setTimeout(() => {
            this.message = '';
          }, 3000);
        }
      },
      (error) => {
        console.error('Error de servidor', error);
        this.message = 'Hubo un error al intentar iniciar sesión. Intenta de nuevo.';
  
        // Borra el mensaje después de 3 segundos
        setTimeout(() => {
          this.message = '';
        }, 3000);
      }
    );
  }
  

  navigateUsuarioCreate() {
    this.router.navigate(["/Registro"]);
  }
}
