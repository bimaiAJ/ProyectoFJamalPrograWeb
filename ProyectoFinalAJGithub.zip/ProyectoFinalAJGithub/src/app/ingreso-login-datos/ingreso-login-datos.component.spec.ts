import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IngresoLoginDatosComponent } from './ingreso-login-datos.component';

describe('IngresoLoginDatosComponent', () => {
  let component: IngresoLoginDatosComponent;
  let fixture: ComponentFixture<IngresoLoginDatosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [IngresoLoginDatosComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IngresoLoginDatosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
