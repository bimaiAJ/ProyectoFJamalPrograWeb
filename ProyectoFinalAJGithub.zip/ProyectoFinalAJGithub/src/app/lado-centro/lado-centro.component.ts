import { Component } from '@angular/core';
import { UsuarioService } from '../services/usuario.service';
import { Usuario } from '../data/usuario';
import { FormsModule } from '@angular/forms';
import { count } from 'node:console';
import { Router } from '@angular/router';
import { RestUsuarioService } from '../services/rest-usuario.service';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-lado-centro',
  standalone: true,
  imports: [FormsModule, NgIf],
  templateUrl: './lado-centro.component.html',
  styleUrl: './lado-centro.component.css'
})
export class LadoCentroComponent {
  private router:Router = new Router;
  usuario: Usuario;
  message: string = "";

  constructor(private restUsuariosService : RestUsuarioService){
    this.usuario =new Usuario();
  }

  saveNewUser(){
    this.restUsuariosService.saveNewUser(this.usuario).subscribe(
      (response) => {
        if (response.success) {
          this.message = 'Usuario creado con éxito';
          this.usuario.Usuario = '';
          this.usuario.nombre_completo = '';
          this.usuario.contrasena = '';
  
          // Borra el mensaje después de 3 segundos
          setTimeout(() => {
            this.message = '';
          }, 3000);
          
        } else {
          this.message = 'Error al crear el usuario';
        }
      },
      (error) => {
        console.error('Error de servidor:', error);
        this.message = 'Hubo un error al intentar crear el usuario.';
      }
    )
  }
  isPasswordValid(password: String): boolean {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    return passwordRegex.test(password.toString());
  }
  
  

  navigateUsuarioLogin(){
    this.router.navigate([""]);
   }
}
