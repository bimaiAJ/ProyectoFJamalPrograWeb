import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LadoCentroComponent } from './lado-centro.component';

describe('LadoCentroComponent', () => {
  let component: LadoCentroComponent;
  let fixture: ComponentFixture<LadoCentroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LadoCentroComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LadoCentroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
