import { Component } from '@angular/core';

@Component({
  selector: 'app-lado-izquierdo',
  standalone: true,
  imports: [],
  templateUrl: './lado-izquierdo.component.html',
  styleUrl: './lado-izquierdo.component.css'
})
export class LadoIzquierdoComponent {

}
