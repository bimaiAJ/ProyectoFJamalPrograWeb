import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RestResponse } from '../data/rest-response';
import { Usuario } from '../data/usuario';
import { Mensaje } from '../data/mensaje';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RestUsuarioService {

  constructor(private http:HttpClient) { }

  
saveNewUser(body:Usuario){
    return this.http.post<RestResponse>('/student/create', body);
  }

  logUsuario(body:Usuario){
    return this.http.post<RestResponse>('/student/findUser', body);
  } 

  crearMensaje(mensaje: Mensaje) {
    return this.http.post<RestResponse>('student/create/mensajes', mensaje);
  }
  getMisMensajes(id_usuario: number) {
    //return this.http.get<RestResponse>(student/misMensajes/${id_usuario}); // Usa backticks
  }

  getMensajesSeguidos(id_usuario: number){
    //return this.http.get<RestResponse>(usuarios/mensajesSeguidos/${id_usuario}); // Usa backticks
  }
}
