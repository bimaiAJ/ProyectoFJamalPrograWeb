import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Mensaje } from '../data/mensaje';
import { RestUsuarioService } from '../services/rest-usuario.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mensajes',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './mensajes.component.html',
  styleUrl: './mensajes.component.css'
})
export class MensajesComponent {
  mensaje: Mensaje = { mensajes: '', id_usuario: 0, fechamensaje: '' };
  message: string = "";
  misMensajes: any[] = [];   // Mensajes propios
  mensajesSeguidos: any[] = [];  // Mensajes de los usuarios seguidos

  constructor(
    private restUsuariosService: RestUsuarioService,
    private router: Router
  ) {}

  crearMensaje() {
    this.mensaje.fechamensaje = new Date().toISOString();

    this.restUsuariosService.crearMensaje(this.mensaje).subscribe(
      (response) => {
        if (response.success) {
          this.message = 'Mensaje creado con éxito';
          this.mensaje.mensajes = '';
          //this.obtenerMensajes();  // Refresca los mensajes después de crear uno
        } else {
          this.message = 'Error al crear el mensaje';
        }
      },
      (error) => {
        console.error('Error de servidor:', error);
        this.message = 'Hubo un error al intentar crear el mensaje.';
      }
    );
  }
  ngOnInit(): void {
    const usuarioId = localStorage.getItem('id_usuario');
    if (usuarioId) {
      this.mensaje.id_usuario = parseInt(usuarioId, 10);
      this.obtenerMensajes();  // Llama a la función para obtener los mensajes
      this.obtenerMensajesSeguidos();  // Llama a la función para obtener los mensajes seguidos
    } else {
      console.error('Error: No se encontró el id_usuario en localStorage.');
      this.message = 'Por favor inicia sesión nuevamente.';
    }
  }

  obtenerMensajes(): void {
    
  }

  obtenerMensajesSeguidos(): void {
   
  }

  cerrarSesion() {
    localStorage.removeItem('id_usuario');
    this.router.navigate(['']);
  }

}
