import { Component } from '@angular/core';

@Component({
  selector: 'app-lado-derecho',
  standalone: true,
  imports: [],
  templateUrl: './lado-derecho.component.html',
  styleUrl: './lado-derecho.component.css'
})
export class LadoDerechoComponent {

}
