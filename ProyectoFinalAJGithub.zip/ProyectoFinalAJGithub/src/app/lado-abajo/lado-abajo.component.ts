import { Component } from '@angular/core';

@Component({
  selector: 'app-lado-abajo',
  standalone: true,
  imports: [],
  templateUrl: './lado-abajo.component.html',
  styleUrl: './lado-abajo.component.css'
})
export class LadoAbajoComponent {

}
