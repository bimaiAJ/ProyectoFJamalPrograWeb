import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LadoAbajoComponent } from './lado-abajo.component';

describe('LadoAbajoComponent', () => {
  let component: LadoAbajoComponent;
  let fixture: ComponentFixture<LadoAbajoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LadoAbajoComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LadoAbajoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
