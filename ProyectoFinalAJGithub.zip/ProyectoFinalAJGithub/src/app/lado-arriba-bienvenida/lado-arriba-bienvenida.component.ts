import { Component } from '@angular/core';

@Component({
  selector: 'app-lado-arriba-bienvenida',
  standalone: true,
  imports: [],
  templateUrl: './lado-arriba-bienvenida.component.html',
  styleUrl: './lado-arriba-bienvenida.component.css'
})
export class LadoArribaBienvenidaComponent {
  nombreUsuario: string | null = '';

  constructor() {
    this.nombreUsuario = localStorage.getItem('nombre_usuario');
  }

}
