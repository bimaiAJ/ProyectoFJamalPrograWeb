import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LadoArribaBienvenidaComponent } from './lado-arriba-bienvenida.component';

describe('LadoArribaBienvenidaComponent', () => {
  let component: LadoArribaBienvenidaComponent;
  let fixture: ComponentFixture<LadoArribaBienvenidaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LadoArribaBienvenidaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LadoArribaBienvenidaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
