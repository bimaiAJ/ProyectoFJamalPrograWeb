import { Component } from '@angular/core';
import { LadoArribaComponent } from "../lado-arriba/lado-arriba.component";
import { LadoAbajoComponent } from "../lado-abajo/lado-abajo.component";
import { LadoCentroComponent } from "../lado-centro/lado-centro.component";
import { LadoIzquierdoComponent } from "../lado-izquierdo/lado-izquierdo.component";
import { LadoDerechoComponent } from '../lado-derecho/lado-derecho.component';


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [LadoArribaComponent, LadoAbajoComponent, LadoCentroComponent,LadoDerechoComponent,LadoIzquierdoComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

}

