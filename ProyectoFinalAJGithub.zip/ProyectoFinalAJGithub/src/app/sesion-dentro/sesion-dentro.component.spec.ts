import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SesionDentroComponent } from './sesion-dentro.component';

describe('SesionDentroComponent', () => {
  let component: SesionDentroComponent;
  let fixture: ComponentFixture<SesionDentroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SesionDentroComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SesionDentroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
