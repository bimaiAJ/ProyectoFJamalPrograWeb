import { Component } from '@angular/core';
import { LadoAbajoComponent } from '../lado-abajo/lado-abajo.component';
import { IngresoLoginDatosComponent } from '../ingreso-login-datos/ingreso-login-datos.component';
import { LadoDerechoComponent } from '../lado-derecho/lado-derecho.component';
import { LadoIzquierdoComponent } from '../lado-izquierdo/lado-izquierdo.component';
import { LadoArribaBienvenidaComponent } from '../lado-arriba-bienvenida/lado-arriba-bienvenida.component';
import { MensajesComponent } from '../mensajes/mensajes.component';


@Component({
  selector: 'app-sesion-dentro',
  standalone: true,
  imports: [LadoArribaBienvenidaComponent, LadoAbajoComponent, MensajesComponent,LadoDerechoComponent,LadoIzquierdoComponent],
  templateUrl: './sesion-dentro.component.html',
  styleUrl: './sesion-dentro.component.css'
})
export class SesionDentroComponent {

}
