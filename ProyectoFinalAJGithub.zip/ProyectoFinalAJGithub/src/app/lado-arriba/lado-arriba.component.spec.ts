import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LadoArribaComponent } from './lado-arriba.component';

describe('LadoArribaComponent', () => {
  let component: LadoArribaComponent;
  let fixture: ComponentFixture<LadoArribaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LadoArribaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LadoArribaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
