import { Component } from '@angular/core';

@Component({
  selector: 'app-lado-arriba',
  standalone: true,
  imports: [],
  templateUrl: './lado-arriba.component.html',
  styleUrl: './lado-arriba.component.css'
})
export class LadoArribaComponent {

}
