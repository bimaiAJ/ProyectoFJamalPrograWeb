import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { IngresoLoginComponent } from './ingreso-login/ingreso-login.component';
import { SesionDentroComponent } from './sesion-dentro/sesion-dentro.component';

export const routes: Routes = [
    {
        path:"", 
        component: IngresoLoginComponent
    },
    {
        path:"Registro", 
        component: LoginComponent
    },
    {
        path:"LoginE", 
        component: SesionDentroComponent
    }
];
