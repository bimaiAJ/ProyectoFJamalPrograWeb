import { Mensaje } from './mensaje';

describe('Mensaje', () => {
  it('should create an instance', () => {
    expect(new Mensaje()).toBeTruthy();
  });
});
