export class Usuario {
    nombre_completo:String = "";
    Usuario:String = "";
    contrasena:String="";
}
