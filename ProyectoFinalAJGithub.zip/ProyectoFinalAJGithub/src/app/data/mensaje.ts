export class Mensaje {
   
        mensajes: string = "";
        fechamensaje: string = "";
        id_usuario: number = 0;
    
}
