import { Component } from '@angular/core';
import { LadoArribaComponent } from '../lado-arriba/lado-arriba.component';
import { LadoAbajoComponent } from '../lado-abajo/lado-abajo.component';
import { IngresoLoginDatosComponent } from '../ingreso-login-datos/ingreso-login-datos.component';
import { LadoDerechoComponent } from '../lado-derecho/lado-derecho.component';
import { LadoIzquierdoComponent } from '../lado-izquierdo/lado-izquierdo.component';


@Component({
  selector: 'app-ingreso-login',
  standalone: true,
  imports: [LadoArribaComponent, LadoAbajoComponent, IngresoLoginDatosComponent,LadoDerechoComponent,LadoIzquierdoComponent],
  templateUrl: './ingreso-login.component.html',
  styleUrl: './ingreso-login.component.css'
})
export class IngresoLoginComponent {

}
