var express = require('express');
var db = require('../db');
var router = express.Router();

router.get('/', async(req,res) => {
    res.status(200),
    res.json({message: "Estudiantes"});
})

//estudiantes
router.get('/all', async(req,res) => {
    try{
        const result = await db.query('SELECT * FROM usuarios');
        res.status(200);
        res.json({success: true, data: result.rows});

    }catch(err){
        res.status(500);
        res.json({success: false});
        console.log(err);
    }


})





//ver todos los mensajes 
router.get('/all/mensajes', async(req,res) => {
    try{
        const result = await db.query('SELECT * FROM mensajes');
        res.status(200);
        res.json({success: true, data: result.rows});

    }catch(err){
        res.status(500);
        res.json({success: false});
        console.log(err);
    }


})




//este muestra los mensajes que uno tiene ya en general los ulitmos 3 
router.get('/all/mensajes/generate', async(req,res) => {
    try{
        const result = await db.query('select * from mensajes order by fechamensaje desc limit 3;');
        res.status(200);
        res.json({success: true, data: result.rows});

    }catch(err){
        res.status(500);
        res.json({success: false});
        console.log(err);
    }


})


//esta parte es para ver los mensajes que uno sigue 
router.get('/all/mensajes/:id_usuario', async(req,res) => {
    try{
        const result = await db.query('select * from mensajes where id_usuario in (1,3) order by fechamensaje desc limit 3;');
        res.status(200);
        res.json({success: true, data: result.rows});

    }catch(err){
        res.status(500);
        res.json({success: false});
        console.log(err);
    }


})

//para encontrar el usuario
router.get('/findOne/:id_usuario', async(req,res) => {
    try{
        
        const result = await db.query('SELECT id_usuario, usuario, Nombre_Completo, Contrasena FROM usuarios where id_usuario = $1', [req.params.id_usuario]);
        res.status(200);
        res.json({success: true, data: result.rows});

    }catch(err){
        res.status(500);
        res.json({success: false});
        console.log(err);
    }


})


////Crea mensajes del usuario
router.post('/create/mensajes', async (req, res) => {
    try {
        var data = req.body;
        const result = await db.query(
            'INSERT INTO mensajes (mensajes, fechamensaje, id_usuario) VALUES($1,$2,$3)', [data.mensajes, data.fechamensaje, data.id_usuario]);
        res.status(200);
        res.json({ success: true, message: "mensaje creado" });

    } catch (err) {
        res.status(500);
        res.json({ success: false });
        console.log(err);

    }
})

// encontrar el usuario 
router.post('/findUser', async (req, res) => {
    try {
        var data = req.body;

        // Consulta para verificar si existe el usuario con la contraseña proporcionada
        const result = await db.query('SELECT ID_Usuario, Usuario, Nombre_Completo FROM USUARIOS WHERE Usuario = $1 AND contrasena = $2',
            [data.Usuario, data.contrasena]);

        // Si no hay resultados, devuelve un error
        if (result.rows.length === 0) {
            return res.status(401).json({ success: false, message: 'Usuario o contraseña incorrectos' });
        }

        // Si el usuario es encontrado, responde con éxito
        res.status(200).json({ success: true, data: result.rows[0] });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Error en el servidor' });
        console.log(err);
    }
})


// crear usuarios 
router.post('/create', async (req, res) => {
    try {
        var data = req.body;
        const result = await db.query('insert into USUARIOS (Usuario, Nombre_Completo, contrasena) values($1,$2,$3)',
            [data.Usuario, data.nombre_completo, data.contrasena]
        );
        res.status(200);
        res.json({ success: true, message: 'Usuario Creado' });
    } catch (err) {
        res.status(500);
        res.json({ success: false });
        console.log(err);
    }
})

router.put('/update', async(req,res)=>{
    try{
        var data=req.body;
        const result = await db.query(
            'UPDATE usuarios SET usuario = $2, nombre_completo = $3 WHERE id_usuario = $1', [data.id_usuario, data.usuario, data.nombre_completo]
        )
        res.status(200);
        res.json({success: true, message: "usuario actualizado"});

    }catch(err){
        res.status(500);
        res.json({success: false});
        console.log(err);

    }
})

router.delete('/delete/:id_usuario', async(req,res)=>{
    try{
        var data=req.body;
        const result = await db.query(
            'DELETE FROM usuarios WHERE id_usuario = $1', [req.params.id_usuario]
                    )
        res.status(200);
        res.json({success: true, message: "usuario eliminado"});

    }catch(err){
        res.status(500);
        res.json({success: false});
        console.log(err);

    }
})

module.exports = router; 